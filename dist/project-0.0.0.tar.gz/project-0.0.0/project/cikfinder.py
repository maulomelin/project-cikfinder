
print(f"This is the cikfinder module!")
